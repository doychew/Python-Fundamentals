from project.beverage.hotbeverage import HotBeverage


class Tea(HotBeverage):
    pass
